function abrirVentana() {
    window.open("$(requestScope.action)", "nuevo", "directories=no, location=no, menubar=no, scrollbars=yes, statusbar=no, tittlebar=no, width=400, height=400");
}
